package oppg1;

public class main {
    public static void main(String[] args) {
        UnikeTall ny = new UnikeTall(40);
        ny.skrivUt();
    }
}
